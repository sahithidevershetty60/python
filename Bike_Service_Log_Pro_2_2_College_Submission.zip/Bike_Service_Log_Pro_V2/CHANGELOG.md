# Changelog

## 2.1 — Reliability and maintainability update

- Added connection lifecycle management with guaranteed close and transaction rollback.
- Added write serialization, SQLite WAL mode, and a configurable busy timeout.
- Added stronger field validation and escaped literal search input.
- Corrected planned next-service date validation so future reminders are accepted.
- Added consistent online database backup and integrity diagnostics (`health` command).
- Expanded automated tests for CRUD, validation, migration, backup/restore, and concurrent writes.
- Added GitHub Actions test workflow and architecture/API/testing documentation.
- Preserved the existing CLI/GUI workflows, sample data, and SQLite data model.
