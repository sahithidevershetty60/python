# Bike Service Log Pro 2.1

A Python bike-maintenance tracker with a command-line interface (CLI), optional Tkinter desktop interface, and SQLite persistence. Version 2.1 strengthens database reliability, validation, planned-service reminders, backups, automated tests, and developer documentation.

## Main features

- Create, view, search, update, and delete service records.
- Service reminders based on both planned service date and odometer reading.
- Fleet summary: record totals, status breakdown, records per bike, and average recorded mileage.
- CSV export and SQLite online backup.
- Input validation for required fields, ISO dates, whole-number odometer values, and odometer consistency.
- Future **next-service dates** are accepted; historical service dates in the future are rejected.
- SQLite constraints, parameterized SQL, indexes, WAL mode, and a busy timeout.
- Short-lived database connections with guaranteed cleanup and rollback on failed writes.
- Thread-safe write serialization within a `ServiceManager` instance.
- Legacy JSON import on first run when the target database is empty.
- Database integrity diagnostic command and automated regression/concurrency tests.
- GitHub Actions workflow runs tests on Python 3.10, 3.11, and 3.12.

## Requirements

- Python 3.10 or newer
- Tkinter for desktop GUI (usually bundled with Python; Linux may require `python3-tk`)
- `pytest` only for running tests

## Install and run (Windows PowerShell)

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python main.py
```

If PowerShell blocks environment activation, run the app with `.venv\Scripts\python.exe main.py` instead.

## CLI commands

Run these from the project folder:

```bash
python main.py                 # interactive CLI
python main.py --gui           # desktop GUI
python main.py list            # list service records
python main.py search Yamaha   # search bike/category/notes
python main.py alerts           # due and overdue reminders
python main.py stats            # fleet summary
python main.py export --out report.csv
python main.py backup --out backups/bike_service.db
python main.py health           # SQLite integrity diagnostics
```

## Run automated tests

```bash
python -m pip install pytest
python -m pytest -q
```

The tests cover CRUD operations, validation boundaries, future reminder dates, status calculations, literal search behaviour, backup/restore, legacy import, bulk import, database health, and concurrent writes.

## Data and configuration

The default database is `data/bike_service.db`. Optional environment variables:

| Variable | Purpose | Default |
|---|---|---|
| `BIKE_SERVICE_DB_PATH` | SQLite database file | `data/bike_service.db` |
| `BIKE_SERVICE_DATA_DIR` | GUI/data directory | `data` |
| `BIKE_SERVICE_LOG_DIR` | Application log directory | `logs` |
| `BIKE_SERVICE_LEGACY_JSON` | Legacy JSON import source | `data/services.json` |

`.env.example` documents the settings; the application does not require a dotenv package. Do not upload real customer data, database files, logs, or secrets to a public repository.

## Project structure

```text
Bike_Service_Log_Pro_V2/
├── main.py                     # CLI, Tkinter UI, and application entry point
├── service_manager.py          # Validation, business rules, SQLite and backup layer
├── data/                       # Sample CSV and legacy JSON data
├── tests/                      # Automated regression and concurrency tests
├── docs/                       # Architecture and API notes
├── .github/workflows/tests.yml # Continuous integration
├── .env.example
├── .gitignore
└── requirements.txt
```

## Architecture

The presentation layer (`main.py`) calls the business/persistence layer (`service_manager.py`). The manager validates input, applies service-status rules, and owns all SQL access. SQLite stores records and indexes common lookup fields. Tests exercise the manager independently of the GUI.

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md), [docs/SERVICE_MANAGER_API.md](docs/SERVICE_MANAGER_API.md), and [docs/TESTING.md](docs/TESTING.md) for details.

## Academic evaluation note

This release implements concrete engineering improvements, but no software change can guarantee a particular automated or faculty score. Submit the project you understand, run the tests yourself, and be prepared to explain the design and demonstrate its features.
