# College submission checklist

- [ ] Extract the ZIP into a new folder; do not upload the ZIP while it contains your personal database or logs.
- [ ] Install the required Python version and run the commands in `README.md`.
- [ ] Run `python -m pytest -q` and retain the actual terminal output as test evidence.
- [ ] Run `python main.py stats` and `python main.py health`.
- [ ] Demonstrate add, search, edit, delete, alerts, CSV export, and database backup.
- [ ] If your evaluator expects a desktop application, demonstrate `python main.py --gui` on a machine with Tkinter.
- [ ] Explain the separation between `main.py` and `service_manager.py`, parameterized SQL, transaction rollback, WAL, validation, and the test suite.
- [ ] Upload the extracted project or ZIP according to your college portal's instructions.

Do not claim a test, feature, or score unless you have personally verified it. Automated marks depend on the portal's rubric and environment; this checklist is not a score guarantee.
