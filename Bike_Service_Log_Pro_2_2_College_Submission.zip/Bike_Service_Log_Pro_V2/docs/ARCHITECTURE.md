# Architecture and design notes

## Layer responsibilities

- **Presentation (`main.py`)**: CLI argument parsing, interactive terminal workflow, Tkinter screens, and CSV presentation/export. It does not build SQL statements.
- **Business and persistence (`service_manager.py`)**: validates records, calculates reminder status, executes parameterized SQL, manages transactions, performs imports, and creates online backups.
- **Storage (SQLite)**: `service_records` table plus indexes on bike name, service date, next-service date, and bike/date combinations.
- **Quality checks (`tests/`)**: tests the manager using temporary databases so tests do not alter a user's working data.

## Data flow

```mermaid
flowchart TD
    A[CLI or Tkinter UI] --> B[ServiceManager]
    B --> C{Validate input}
    C -->|Invalid| D[Field-specific error]
    C -->|Valid| E[Parameterized SQL]
    E --> F[(SQLite database)]
    F --> G[Records and summary results]
    G --> A
    H[pytest suite] --> B
    I[GitHub Actions] --> H
```

## Reliability decisions

1. Each operation opens its own SQLite connection and closes it in a `finally` block. This avoids sharing one connection between UI threads.
2. Write operations are serialized by a re-entrant lock within one manager instance. SQLite WAL mode and a busy timeout help coordinate database access from other connections/processes.
3. A successful write commits; a failed operation rolls back and re-raises the original exception.
4. SQL values are passed as parameters. Search wildcard characters are escaped so user input is treated as a literal search term.
5. The online backup API creates a consistent copy and includes committed WAL content.
6. Database constraints provide a second validation boundary in addition to application-level checks.

## Service reminder rules

- A next-service date on or before today is `OVERDUE`.
- A next-service date within the next 14 days is `DUE SOON`.
- Otherwise, reaching or passing the next-service odometer is `KM OVERDUE`.
- Being within 500 km of the next-service odometer is `KM SOON`.
- If none applies, the record is `OK`.
- Date reminders take priority over odometer reminders.

A planned next-service date is expected to be in the future, so it is allowed. A recorded service date cannot be in the future.

## Scope and limitations

The lock coordinates writes made through the same `ServiceManager` instance; it is not a distributed lock. SQLite's own locking and busy timeout coordinate separate connections/processes. The application is a local maintenance log, not a multi-user hosted service; authentication and role management were outside the original project scope.
