# ServiceManager API reference

Import with `from service_manager import ServiceManager, DataValidationError`.

| Method | Purpose | Return |
|---|---|---|
| `ServiceManager(database_path)` | Create manager and initialize schema | Manager instance |
| `validate_record(record)` | Validate and normalize user data | Clean dictionary; raises `DataValidationError` |
| `add_record(record)` | Insert one record | New integer ID |
| `get_record(record_id)` | Fetch by ID | Dictionary or `None` |
| `list_records()` | List newest records first | List of dictionaries |
| `search_records(query, status_filter)` | Search bike/category/notes and filter status | List of dictionaries |
| `update_record(record_id, record)` | Update an existing record | Boolean |
| `delete_record(record_id)` | Delete by ID | Boolean |
| `import_records(records)` | Bulk insert validated records | `(inserted_count, rejected_count)` |
| `get_summary_stats(today)` | Fleet totals and status counts | Dictionary |
| `status_for(record, today)` | Calculate reminder status | Status string |
| `backup_database(destination)` | Create a consistent SQLite backup | `Path` |
| `database_health()` | Run SQLite integrity diagnostics | Diagnostic dictionary |

## Record fields

`bike_name`, `service_date`, `odometer_km`, `category`, and `notes` are required. `next_service_km`, `next_service_date`, and `current_odometer_km` are optional and default to zero/blank. Dates use `YYYY-MM-DD`. Odometer values are whole kilometres. The current odometer, when supplied, cannot be lower than the recorded service odometer.

## Exception handling

Invalid data raises `DataValidationError`, which is also a `ValueError`. SQLite failures retain their `sqlite3` exception type so callers can distinguish storage errors from validation errors.
