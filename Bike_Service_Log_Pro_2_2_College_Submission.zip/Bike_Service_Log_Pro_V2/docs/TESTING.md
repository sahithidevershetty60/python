# Test and verification guide

## Local verification

1. Create and activate a virtual environment.
2. Install `pytest` with `python -m pip install pytest`.
3. Run `python -m pytest -q` from the project root.
4. Run `python -m py_compile main.py service_manager.py`.
5. Start the CLI with `python main.py`, then try `list`, `stats`, and `health`.
6. Create a backup with `python main.py backup --out backups/demo.db`.
7. If desktop testing is available, launch `python main.py --gui` and verify add/edit/delete/search workflows.

## Automated coverage

The suite verifies record lifecycle, missing IDs, invalid values, future-date rules, odometer consistency, reminder boundaries, search escaping, summary statistics, backup restoration, database integrity, concurrent inserts, legacy JSON migration, and bulk-import accounting.

The GitHub Actions workflow repeats the automated tests on Python 3.10, 3.11, and 3.12 for pushes and pull requests. A green CI run means the automated suite passed on that runner; it does not replace manual GUI acceptance testing.
