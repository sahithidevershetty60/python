"""Validated, thread-aware SQLite service-log business layer.

The UI layer should call this class rather than issuing SQL directly. Every
operation uses a short-lived connection; writes are serialized per manager and
SQLite WAL/busy_timeout coordinate separate processes.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import date, datetime
import json
import os
from pathlib import Path
import sqlite3
from threading import RLock
from typing import Iterator


FIELDS = ("id", "bike_name", "service_date", "odometer_km", "category", "notes",
          "next_service_km", "next_service_date", "current_odometer_km")
INSERT_FIELDS = FIELDS[1:]
STATUSES = ("OVERDUE", "DUE SOON", "KM OVERDUE", "KM SOON", "OK")


class ServiceManagerError(Exception):
    """Base exception for service-log operations."""


class DataValidationError(ServiceManagerError, ValueError):
    """Raised when user-supplied service data is invalid."""


class ServiceManager:
    """Manage service records in SQLite.

    Args:
        database_path: SQLite database path. Defaults to the
            ``BIKE_SERVICE_DB_PATH`` environment variable or
            ``data/bike_service.db``.

    Dates use ISO ``YYYY-MM-DD`` format. A service date cannot be in the
    future; a *next service date* may be in the future by definition.
    """

    def __init__(self, database_path=None):
        configured = database_path or os.getenv("BIKE_SERVICE_DB_PATH", "data/bike_service.db")
        self.database_path = Path(configured).expanduser()
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._write_lock = RLock()
        self.initialize()

    def _new_connection(self) -> sqlite3.Connection:
        con = sqlite3.connect(str(self.database_path), timeout=20)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys = ON")
        con.execute("PRAGMA busy_timeout = 20000")
        return con

    @contextmanager
    def _connection(self, *, write=False) -> Iterator[sqlite3.Connection]:
        """Provide commit/rollback/close guarantees for every DB operation."""
        lock = self._write_lock if write else _NoOpLock()
        with lock:
            con = self._new_connection()
            try:
                yield con
                if write:
                    con.commit()
            except Exception:
                if write:
                    con.rollback()
                raise
            finally:
                con.close()

    def initialize(self) -> None:
        """Create schema/indexes and safely import legacy JSON once."""
        with self._connection(write=True) as con:
            con.execute("PRAGMA journal_mode = WAL")
            con.execute("""CREATE TABLE IF NOT EXISTS service_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bike_name TEXT NOT NULL CHECK(length(trim(bike_name)) > 0),
                service_date TEXT NOT NULL,
                odometer_km INTEGER NOT NULL CHECK(odometer_km > 0),
                category TEXT NOT NULL CHECK(length(trim(category)) > 0),
                notes TEXT NOT NULL CHECK(length(trim(notes)) > 0),
                next_service_km INTEGER NOT NULL DEFAULT 0 CHECK(next_service_km >= 0),
                next_service_date TEXT NOT NULL DEFAULT '',
                current_odometer_km INTEGER NOT NULL DEFAULT 0 CHECK(current_odometer_km >= 0)
            )""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_service_bike ON service_records(bike_name)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_service_date ON service_records(service_date)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_service_due_date ON service_records(next_service_date)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_service_bike_date ON service_records(bike_name, service_date)")
            count = con.execute("SELECT COUNT(*) FROM service_records").fetchone()[0]
            legacy_env = os.getenv("BIKE_SERVICE_LEGACY_JSON")
            legacy_path = Path(legacy_env) if legacy_env else self.database_path.parent / "services.json"
            if count == 0 and legacy_path.is_file():
                self._import_legacy_json(con, legacy_path)

    @classmethod
    def _import_legacy_json(cls, con: sqlite3.Connection, path: Path) -> int:
        """Import valid legacy rows; malformed rows are skipped, not fatal."""
        try:
            payload = json.loads(path.read_text(encoding="utf-8-sig"))
        except (OSError, json.JSONDecodeError):
            return 0
        if not isinstance(payload, list):
            return 0
        imported = 0
        for raw in payload:
            if not isinstance(raw, dict):
                continue
            try:
                clean = cls.validate_record(raw)
                explicit_id = raw.get("id")
                columns = ", ".join(INSERT_FIELDS)
                placeholders = ", ".join("?" for _ in INSERT_FIELDS)
                values = [clean[k] for k in INSERT_FIELDS]
                if explicit_id not in (None, ""):
                    con.execute(
                        f"INSERT OR IGNORE INTO service_records (id, {columns}) VALUES (?, {placeholders})",
                        [int(explicit_id), *values],
                    )
                else:
                    con.execute(
                        f"INSERT INTO service_records ({columns}) VALUES ({placeholders})", values
                    )
                imported += 1
            except (DataValidationError, sqlite3.IntegrityError, TypeError, ValueError):
                continue
        return imported

    @staticmethod
    def validate_record(record: dict) -> dict:
        """Normalize a record or raise a field-specific DataValidationError."""
        if not isinstance(record, dict):
            raise DataValidationError("A service record must be a dictionary.")
        bike = str(record.get("bike_name", "")).strip()
        category = str(record.get("category", "")).strip()
        notes = str(record.get("notes", "") or "").strip()
        if not bike:
            raise DataValidationError("Bike name cannot be blank.")
        if not category:
            raise DataValidationError("Service category cannot be blank.")
        if not notes:
            raise DataValidationError("Notes cannot be blank.")

        def parse_date(value, field, *, optional=False, allow_future=False):
            value = str(value or "").strip()
            if not value and optional:
                return ""
            try:
                parsed = datetime.strptime(value, "%Y-%m-%d").date()
            except ValueError as exc:
                raise DataValidationError(f"{field} must use YYYY-MM-DD format.") from exc
            if not allow_future and parsed > date.today():
                raise DataValidationError(f"{field} cannot be in the future.")
            return parsed.isoformat()

        def parse_km(value, field, *, allow_zero=True):
            if isinstance(value, bool):
                raise DataValidationError(f"{field} must be a whole number.")
            try:
                number = int(value)
            except (TypeError, ValueError, OverflowError) as exc:
                raise DataValidationError(f"{field} must be a whole number.") from exc
            if str(value).strip() not in (str(number), f"+{number}") and not isinstance(value, int):
                raise DataValidationError(f"{field} must be a whole number.")
            if number < (0 if allow_zero else 1):
                raise DataValidationError(f"{field} must be {'non-negative' if allow_zero else 'positive'}.")
            return number

        service_date = parse_date(record.get("service_date"), "Service date")
        next_date = parse_date(record.get("next_service_date", ""), "Next service date",
                               optional=True, allow_future=True)
        odometer = parse_km(record.get("odometer_km"), "Odometer", allow_zero=False)
        next_km = parse_km(record.get("next_service_km", 0) or 0, "Next service km")
        current_km = parse_km(record.get("current_odometer_km", 0) or 0, "Current odometer")
        if current_km and current_km < odometer:
            raise DataValidationError("Current odometer cannot be lower than the service odometer.")
        return {"bike_name": bike, "service_date": service_date, "odometer_km": odometer,
                "category": category, "notes": notes, "next_service_km": next_km,
                "next_service_date": next_date, "current_odometer_km": current_km}

    def list_records(self) -> list[dict]:
        """Return records ordered by newest service date, then highest ID."""
        with self._connection() as con:
            rows = con.execute("SELECT * FROM service_records ORDER BY service_date DESC, id DESC").fetchall()
        return [dict(row) for row in rows]

    def get_record(self, record_id) -> dict | None:
        """Return one record by ID, or None if it does not exist."""
        with self._connection() as con:
            row = con.execute("SELECT * FROM service_records WHERE id = ?", (int(record_id),)).fetchone()
        return dict(row) if row else None

    def search_records(self, query="", status_filter="ALL") -> list[dict]:
        """Search bike/category/notes safely and optionally filter by status."""
        sql = "SELECT * FROM service_records WHERE 1=1"
        params = []
        term = str(query or "").strip()
        if term:
            escaped = term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            sql += " AND (bike_name LIKE ? ESCAPE '\\' OR category LIKE ? ESCAPE '\\' OR notes LIKE ? ESCAPE '\\')"
            pattern = f"%{escaped}%"
            params.extend((pattern, pattern, pattern))
        sql += " ORDER BY service_date DESC, id DESC"
        with self._connection() as con:
            records = [dict(row) for row in con.execute(sql, params).fetchall()]
        wanted = str(status_filter or "ALL").strip().upper()
        return records if wanted == "ALL" else [r for r in records if self.status_for(r) == wanted]

    def add_record(self, record: dict) -> int:
        """Validate and insert a record; return its generated primary key."""
        clean = self.validate_record(record)
        columns = ", ".join(INSERT_FIELDS)
        placeholders = ", ".join("?" for _ in INSERT_FIELDS)
        with self._connection(write=True) as con:
            cursor = con.execute(f"INSERT INTO service_records ({columns}) VALUES ({placeholders})",
                                 [clean[k] for k in INSERT_FIELDS])
            return int(cursor.lastrowid)

    def update_record(self, record_id, record: dict) -> bool:
        """Update an existing record; return False if the ID is not present."""
        clean = self.validate_record(record)
        assignments = ", ".join(f"{field} = ?" for field in INSERT_FIELDS)
        with self._connection(write=True) as con:
            cursor = con.execute(f"UPDATE service_records SET {assignments} WHERE id = ?",
                                 [clean[k] for k in INSERT_FIELDS] + [int(record_id)])
            return cursor.rowcount > 0

    def delete_record(self, record_id) -> bool:
        """Delete a record and return whether a row was removed."""
        with self._connection(write=True) as con:
            cursor = con.execute("DELETE FROM service_records WHERE id = ?", (int(record_id),))
            return cursor.rowcount > 0

    def import_records(self, records) -> tuple[int, int]:
        """Import many records in one transaction; return (inserted, rejected)."""
        inserted = rejected = 0
        with self._connection(write=True) as con:
            for record in records:
                try:
                    clean = self.validate_record(record)
                    columns = ", ".join(INSERT_FIELDS)
                    placeholders = ", ".join("?" for _ in INSERT_FIELDS)
                    con.execute(f"INSERT INTO service_records ({columns}) VALUES ({placeholders})",
                                [clean[k] for k in INSERT_FIELDS])
                    inserted += 1
                except (DataValidationError, sqlite3.IntegrityError, TypeError, ValueError):
                    rejected += 1
        return inserted, rejected

    def get_summary_stats(self, today=None) -> dict:
        """Return fleet totals, status counts, per-bike counts and mean mileage."""
        records = self.list_records()
        counts = {status: 0 for status in STATUSES}
        bikes = {}
        for record in records:
            counts[self.status_for(record, today=today)] += 1
            bikes[record["bike_name"]] = bikes.get(record["bike_name"], 0) + 1
        total_km = sum(int(r["odometer_km"]) for r in records)
        return {"total_records": len(records), "status_breakdown": counts,
                "records_per_bike": bikes,
                "average_odometer_km": round(total_km / len(records), 2) if records else 0}

    def backup_database(self, destination) -> Path:
        """Create a consistent online SQLite backup, including committed WAL data."""
        target = Path(destination).expanduser()
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.resolve() == self.database_path.resolve():
            raise ValueError("Backup destination must differ from the active database.")
        with self._connection() as source:
            with sqlite3.connect(str(target)) as backup:
                source.backup(backup)
        return target

    def database_health(self) -> dict:
        """Return SQLite integrity diagnostics useful for support and demos."""
        with self._connection() as con:
            integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
            fk_issues = con.execute("PRAGMA foreign_key_check").fetchall()
            mode = con.execute("PRAGMA journal_mode").fetchone()[0]
        return {"integrity": integrity, "foreign_key_issues": len(fk_issues),
                "journal_mode": mode, "healthy": integrity == "ok" and not fk_issues}

    @staticmethod
    def status_for(item: dict, today=None) -> str:
        """Calculate the most urgent date- or odometer-based service status."""
        today = today or date.today()
        due_date = str(item.get("next_service_date") or "").strip()
        current = int(item.get("current_odometer_km") or 0)
        next_km = int(item.get("next_service_km") or 0)
        if due_date:
            try:
                due = datetime.strptime(due_date, "%Y-%m-%d").date()
                if due <= today:
                    return "OVERDUE"
                if (due - today).days <= 14:
                    return "DUE SOON"
            except ValueError:
                pass
        if current and next_km and current >= next_km:
            return "KM OVERDUE"
        if current and next_km and 0 <= next_km - current <= 500:
            return "KM SOON"
        return "OK"


class _NoOpLock:
    """Context manager for independent read connections."""
    def __enter__(self):
        return self
    def __exit__(self, *_):
        return False
