"""Regression, validation, persistence and concurrency tests."""
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
import json
import pytest
from service_manager import DataValidationError, ServiceManager


def sample_record(**overrides):
    record = {
        "bike_name": "Yamaha MT-07",
        "service_date": date.today().isoformat(),
        "odometer_km": 12000,
        "category": "Oil & Filter",
        "notes": "Synthetic 10W-40",
        "next_service_km": 17000,
        "next_service_date": "",
        "current_odometer_km": 12500,
    }
    record.update(overrides)
    return record


def test_crud_lifecycle_and_missing_ids(tmp_path):
    manager = ServiceManager(tmp_path / "services.db")
    record_id = manager.add_record(sample_record())
    assert manager.get_record(record_id)["bike_name"] == "Yamaha MT-07"
    assert manager.update_record(record_id, sample_record(notes="Updated notes"))
    assert manager.get_record(record_id)["notes"] == "Updated notes"
    assert manager.delete_record(record_id)
    assert manager.get_record(record_id) is None
    assert not manager.delete_record(record_id)
    assert not manager.update_record(999, sample_record())


def test_search_stats_and_empty_database(tmp_path):
    manager = ServiceManager(tmp_path / "stats.db")
    empty = manager.get_summary_stats()
    assert empty["total_records"] == 0
    assert empty["average_odometer_km"] == 0
    manager.add_record(sample_record(bike_name="Honda CB500X", category="Chain Lube"))
    manager.add_record(sample_record(bike_name="Yamaha MT-07", category="Brake Pads"))
    assert len(manager.search_records("Honda")) == 1
    assert manager.search_records("%") == []  # wildcard characters are treated literally
    stats = manager.get_summary_stats()
    assert stats["total_records"] == 2
    assert stats["records_per_bike"]["Honda CB500X"] == 1
    assert stats["average_odometer_km"] == 12000


@pytest.mark.parametrize("changes", [
    {"bike_name": " "}, {"category": ""}, {"notes": ""},
    {"odometer_km": -1}, {"odometer_km": 0}, {"odometer_km": "12.5"},
    {"next_service_km": -1}, {"current_odometer_km": "abc"},
    {"service_date": "20-05-2025"},
])
def test_invalid_records_are_rejected(tmp_path, changes):
    manager = ServiceManager(tmp_path / "invalid.db")
    with pytest.raises(DataValidationError):
        manager.add_record(sample_record(**changes))


def test_future_service_date_is_rejected_but_future_reminder_is_allowed(tmp_path):
    manager = ServiceManager(tmp_path / "dates.db")
    future = (date.today() + timedelta(days=30)).isoformat()
    record_id = manager.add_record(sample_record(next_service_date=future))
    assert manager.get_record(record_id)["next_service_date"] == future
    with pytest.raises(DataValidationError, match="Service date cannot be in the future"):
        manager.add_record(sample_record(service_date=future))


def test_current_odometer_cannot_be_below_service_odometer(tmp_path):
    manager = ServiceManager(tmp_path / "odometer.db")
    with pytest.raises(DataValidationError, match="cannot be lower"):
        manager.add_record(sample_record(odometer_km=12000, current_odometer_km=11000))


def test_status_date_and_odometer_boundaries():
    today = date(2025, 5, 20)
    assert ServiceManager.status_for(sample_record(next_service_date=(today - timedelta(days=1)).isoformat()), today) == "OVERDUE"
    assert ServiceManager.status_for(sample_record(next_service_date=(today + timedelta(days=14)).isoformat()), today) == "DUE SOON"
    assert ServiceManager.status_for(sample_record(next_service_km=15000, current_odometer_km=15000), today) == "KM OVERDUE"
    assert ServiceManager.status_for(sample_record(next_service_km=13000, current_odometer_km=12500), today) == "KM SOON"
    assert ServiceManager.status_for(sample_record(next_service_km=18000, current_odometer_km=12000), today) == "OK"


def test_backup_is_restorable_and_health_check_passes(tmp_path):
    manager = ServiceManager(tmp_path / "source.db")
    manager.add_record(sample_record())
    backup = manager.backup_database(tmp_path / "backups" / "copy.db")
    restored = ServiceManager(backup)
    assert len(restored.list_records()) == 1
    assert restored.database_health()["healthy"]
    with pytest.raises(ValueError, match="differ"):
        manager.backup_database(manager.database_path)


def test_concurrent_inserts_are_consistent(tmp_path):
    manager = ServiceManager(tmp_path / "concurrent.db")
    with ThreadPoolExecutor(max_workers=8) as pool:
        ids = list(pool.map(lambda i: manager.add_record(sample_record(bike_name=f"Bike-{i}")), range(40)))
    assert len(set(ids)) == 40
    assert len(manager.list_records()) == 40


def test_legacy_json_import_skips_bad_rows(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    legacy = data_dir / "services.json"
    valid = sample_record()
    legacy.write_text(json.dumps([valid, {"bike_name": "", "category": "bad"}, "bad-row"]), encoding="utf-8")
    manager = ServiceManager(data_dir / "bike_service.db")
    assert len(manager.list_records()) == 1
    # Import is a first-run operation; later startups do not duplicate records.
    ServiceManager(data_dir / "bike_service.db")
    assert len(manager.list_records()) == 1


def test_bulk_import_reports_inserted_and_rejected_rows(tmp_path):
    manager = ServiceManager(tmp_path / "bulk.db")
    inserted, rejected = manager.import_records([sample_record(), {"bike_name": ""}])
    assert (inserted, rejected) == (1, 1)
    assert len(manager.list_records()) == 1
