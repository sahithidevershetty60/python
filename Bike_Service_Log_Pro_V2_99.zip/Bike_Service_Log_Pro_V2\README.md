﻿# Bike Service Log Pro 2.0

A dual-interface (Terminal CLI & Optional Tkinter GUI) motorcycle maintenance tracker backed by SQLite with incremental CRUD persistence, automated status alerts, fleet analytics, and CSV/Markdown reporting.

## Features
- **Primary Terminal Interface (CLI):** Interactive menu and direct subcommands (`list`, `search`, `alerts`, `stats`, `delete`, `export`) built with `argparse`.
- **Optional Desktop GUI:** Launchable via `--gui` for visual dashboard metrics and table filtering.
- **Incremental SQLite Persistence:** Targeted `INSERT`, `UPDATE`, `DELETE`, and indexed `SELECT` queries without full-table rewrites.
- **Smart Service Reminders:** Multi-criteria status tracking (`OVERDUE`, `DUE SOON`, `KM OVERDUE`, `KM SOON`, `OK`) across both date and odometer thresholds.
- **Configurable Paths:** Supports environment variables for database, data, and log directories.

## Quick Start
- **Terminal Mode (Default):** `python main.py`
- **CLI Subcommands:** `python main.py list`, `python main.py stats`, `python main.py alerts`
- **Graphical Interface (Optional):** `python main.py --gui`
- **Run Automated Tests:** `pytest`
