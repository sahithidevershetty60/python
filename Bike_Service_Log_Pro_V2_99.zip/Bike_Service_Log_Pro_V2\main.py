﻿"""CLI and GUI entry point for Bike Service Log Pro 2.0."""
import argparse
import csv
import logging
import os
from datetime import date, datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from service_manager import FIELDS, ServiceManager

ROOT = Path(__file__).parent
DATA_DIR = Path(os.getenv("BIKE_SERVICE_DATA_DIR", str(ROOT / "data")))
LOG_DIR = Path(os.getenv("BIKE_SERVICE_LOG_DIR", str(ROOT / "logs")))
DB_PATH = Path(os.getenv("BIKE_SERVICE_DB_PATH", str(DATA_DIR / "bike_service.db")))


def setup_logging():
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        filename=LOG_DIR / "bike_service.log",
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        encoding="utf-8",
    )


manager = ServiceManager(DB_PATH)


def valid_date(value, optional=False):
    if optional and not value.strip():
        return True
    try:
        parsed = datetime.strptime(value.strip(), "%Y-%m-%d").date()
        return parsed <= date.today()
    except ValueError:
        return False


def as_int(value, label, allow_zero=True):
    try:
        number = int(value)
        if number < (0 if allow_zero else 1):
            raise ValueError
        return number
    except ValueError:
        kind = "non-negative" if allow_zero else "positive"
        raise ValueError(f"{label} must be a valid {kind} whole number.")


def validate_record_data(raw):
    values = {k: str(raw.get(k, "")).strip() for k in FIELDS if k != "id"}
    if not values["bike_name"] or not values["category"] or not values["notes"]:
        raise ValueError("Bike name, category, and notes cannot be blank.")
    if not valid_date(values["service_date"]):
        raise ValueError("Service date must be YYYY-MM-DD and cannot be in the future.")
    if not valid_date(values["next_service_date"], optional=True):
        raise ValueError("Next service date must be YYYY-MM-DD and cannot be in the future.")

    values["odometer_km"] = as_int(values["odometer_km"], "Odometer", allow_zero=False)
    values["next_service_km"] = as_int(values["next_service_km"] or "0", "Next service odometer")
    values["current_odometer_km"] = as_int(values["current_odometer_km"] or "0", "Current odometer")

    if values["current_odometer_km"] and values["current_odometer_km"] < values["odometer_km"]:
        raise ValueError("Current odometer cannot be lower than the service odometer.")
    return values


def print_records_table(records):
    if not records:
        print("\nNo service records found.\n")
        return
    header = f"{'ID':<4} {'Bike':<20} {'Date':<12} {'Odo (km)':<10} {'Category':<18} {'Status':<12}"
    print("\n" + header)
    print("-" * len(header))
    for r in records:
        status = manager.status_for(r)
        print(
            f"{r['id']:<4} {r['bike_name'][:19]:<20} {r['service_date']:<12} "
            f"{r['odometer_km']:<10,} {r['category'][:17]:<18} {status:<12}"
        )
    print()


def cli_prompt_record(existing=None):
    existing = existing or {}
    print("\nEnter service details (press Enter to keep current/default value):")
    bike = input(f"Bike name [{existing.get('bike_name', '')}]: ").strip() or existing.get("bike_name", "")
    s_date = input(f"Service date YYYY-MM-DD [{existing.get('service_date', date.today().isoformat())}]: ").strip() or existing.get("service_date", date.today().isoformat())
    odo = input(f"Odometer km [{existing.get('odometer_km', '')}]: ").strip() or str(existing.get("odometer_km", ""))
    cat = input(f"Category [{existing.get('category', 'General service')}]: ").strip() or existing.get("category", "General service")
    notes = input(f"Notes [{existing.get('notes', '')}]: ").strip() or existing.get("notes", "")
    next_km = input(f"Next service km (0=unset) [{existing.get('next_service_km', 0)}]: ").strip() or str(existing.get("next_service_km", 0))
    next_date = input(f"Next service date YYYY-MM-DD (optional) [{existing.get('next_service_date', '')}]: ").strip() or existing.get("next_service_date", "")
    curr_odo = input(f"Current odometer km (optional) [{existing.get('current_odometer_km', 0)}]: ").strip() or str(existing.get("current_odometer_km", 0))

    return validate_record_data({
        "bike_name": bike,
        "service_date": s_date,
        "odometer_km": odo,
        "category": cat,
        "notes": notes,
        "next_service_km": next_km,
        "next_service_date": next_date,
        "current_odometer_km": curr_odo,
    })


def cli_show_alerts():
    records = manager.list_records()
    alerts = [r for r in records if manager.status_for(r) != "OK"]
    if not alerts:
        print("\nAll bikes are up to date. No overdue or upcoming services.\n")
        return
    print("\n=== SERVICE ALERTS ===")
    for r in alerts:
        status = manager.status_for(r)
        print(
            f"• [#{r['id']}] {r['bike_name']} — {status} | "
            f"Next Date: {r.get('next_service_date') or 'N/A'} | "
            f"Next Odo: {r.get('next_service_km') or 'N/A'} km"
        )
    print()


def cli_show_stats():
    stats = manager.get_summary_stats()
    print("\n=== FLEET MAINTENANCE SUMMARY ===")
    print(f"Total Service Records : {stats['total_records']}")
    print("Status Breakdown      :", ", ".join(f"{k}: {v}" for k, v in stats["status_breakdown"].items()))
    print("Services per Bike     :")
    for bike, count in stats["records_per_bike"].items():
        print(f"  - {bike}: {count} record(s)")
    print()


def cli_export_csv(filepath):
    records = manager.list_records()
    out_path = Path(filepath)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        for r in records:
            writer.writerow({k: r.get(k, "") for k in FIELDS})
    logging.info("Exported %s records to %s via CLI", len(records), out_path)
    print(f"Exported {len(records)} records to {out_path}")


def run_interactive_cli():
    print("==========================================")
    print("   BIKE SERVICE LOG PRO 2.0 (CLI MODE)    ")
    print("==========================================")
    while True:
        print("1. List all service records")
        print("2. Search records")
        print("3. Add service record")
        print("4. Edit service record")
        print("5. Delete service record")
        print("6. View service alerts")
        print("7. View fleet analytics summary")
        print("8. Export records to CSV")
        print("9. Launch GUI mode")
        print("0. Exit")
        choice = input("\nSelect an option [0-9]: ").strip()

        try:
            if choice == "1":
                print_records_table(manager.list_records())
            elif choice == "2":
                q = input("Search keyword (bike, category, notes): ").strip()
                print_records_table(manager.search_records(query=q))
            elif choice == "3":
                data = cli_prompt_record()
                new_id = manager.add_record(data)
                logging.info("CLI added record #%s for %s", new_id, data["bike_name"])
                print(f"Record #{new_id} added successfully.\n")
            elif choice == "4":
                rec_id = as_int(input("Enter Record ID to edit: ").strip(), "Record ID", allow_zero=False)
                existing = manager.get_record(rec_id)
                if not existing:
                    print(f"Record #{rec_id} not found.\n")
                    continue
                updated = cli_prompt_record(existing)
                manager.update_record(rec_id, updated)
                logging.info("CLI updated record #%s", rec_id)
                print(f"Record #{rec_id} updated successfully.\n")
            elif choice == "5":
                rec_id = as_int(input("Enter Record ID to delete: ").strip(), "Record ID", allow_zero=False)
                if manager.delete_record(rec_id):
                    logging.info("CLI deleted record #%s", rec_id)
                    print(f"Record #{rec_id} deleted.\n")
                else:
                    print(f"Record #{rec_id} not found.\n")
            elif choice == "6":
                cli_show_alerts()
            elif choice == "7":
                cli_show_stats()
            elif choice == "8":
                path = input("Output CSV path [bike_service_report.csv]: ").strip() or "bike_service_report.csv"
                cli_export_csv(path)
            elif choice == "9":
                launch_gui()
                break
            elif choice == "0":
                print("Goodbye!")
                break
            else:
                print("Invalid option. Please enter a number from 0 to 9.\n")
        except ValueError as exc:
            print(f"Input Error: {exc}\n")
        except Exception as exc:
            logging.exception("CLI operation error")
            print(f"System Error: {exc}\n")

class ServiceDialog(tk.Toplevel):
    def __init__(self, parent, title, item=None):
        super().__init__(parent)
        self.title(title)
        self.resizable(False, False)
        self.result = None
        self.transient(parent)
        self.grab_set()
        item = item or {}
        self.vars = {}
        fields = [
            ("bike_name", "Bike name / model", item.get("bike_name", "")),
            ("service_date", "Service date (YYYY-MM-DD)", item.get("service_date", date.today().isoformat())),
            ("odometer_km", "Odometer at service (km)", str(item.get("odometer_km", ""))),
            ("category", "Service category", item.get("category", "General service")),
            ("notes", "Maintenance notes", item.get("notes", "")),
            ("next_service_km", "Next service at (km; 0 = unset)", str(item.get("next_service_km", 0))),
            ("next_service_date", "Next service date (YYYY-MM-DD; optional)", item.get("next_service_date", "")),
            ("current_odometer_km", "Current odometer (km; optional)", str(item.get("current_odometer_km", ""))),
        ]
        body = ttk.Frame(self, padding=14)
        body.grid(row=0, column=0, sticky="nsew")
        for row, (key, label, value) in enumerate(fields):
            ttk.Label(body, text=label).grid(row=row, column=0, sticky="w", padx=(0, 12), pady=5)
            var = tk.StringVar(value=value)
            self.vars[key] = var
            ttk.Entry(body, textvariable=var, width=36).grid(row=row, column=1, pady=5)
        buttons = ttk.Frame(body)
        buttons.grid(row=len(fields), column=0, columnspan=2, sticky="e", pady=(12, 0))
        ttk.Button(buttons, text="Cancel", command=self.destroy).pack(side="right", padx=5)
        ttk.Button(buttons, text="Save", command=self.submit).pack(side="right")
        self.bind("<Return>", lambda _e: self.submit())
        self.wait_visibility()
        self.focus_set()

    def submit(self):
        raw = {key: var.get() for key, var in self.vars.items()}
        try:
            self.result = validate_record_data(raw)
        except ValueError as exc:
            messagebox.showerror("Validation", str(exc), parent=self)
            return
        self.destroy()

class BikeServiceApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Bike Service Log Pro 2.0")
        self.geometry("1120x720")
        self.minsize(900, 600)
        self.configure(bg="#f3f6fb")
        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass
        self.style.configure("Treeview", rowheight=29, font=("Segoe UI", 9))
        self.style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))
        self.style.configure("Title.TLabel", font=("Segoe UI", 20, "bold"), foreground="#16345f")
        self.style.configure("Sub.TLabel", font=("Segoe UI", 9), foreground="#64748b")
        self.style.configure("Card.TLabelframe", padding=12)
        self.build_ui()
        self.refresh()

    def build_ui(self):
        header = ttk.Frame(self, padding=(18, 16))
        header.pack(fill="x")
        ttk.Label(header, text="BIKE SERVICE LOG PRO 2.0", style="Title.TLabel").pack(anchor="w")
        ttk.Label(header, text="Maintenance history • service reminders • reports", style="Sub.TLabel").pack(anchor="w", pady=(3, 0))

        cards = ttk.Frame(self, padding=(18, 0))
        cards.pack(fill="x")
        self.metrics = {}
        for key, label in [("records", "TOTAL RECORDS"), ("bikes", "BIKES TRACKED"), ("due", "DUE / OVERDUE"), ("average", "AVG. ODOMETER")]:
            frame = ttk.LabelFrame(cards, text=label, style="Card.TLabelframe")
            frame.pack(side="left", fill="x", expand=True, padx=(0, 10))
            value = ttk.Label(frame, text="0", font=("Segoe UI", 18, "bold"), foreground="#1d4ed8")
            value.pack(anchor="w")
            self.metrics[key] = value

        toolbar = ttk.Frame(self, padding=(18, 14, 18, 8))
        toolbar.pack(fill="x")
        ttk.Button(toolbar, text="+ Add record", command=self.add_record).pack(side="left")
        ttk.Button(toolbar, text="Edit selected", command=self.edit_record).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Delete selected", command=self.delete_record).pack(side="left")
        ttk.Button(toolbar, text="Service alerts", command=self.show_alerts).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Export CSV", command=self.export_csv).pack(side="right")
        ttk.Button(toolbar, text="Import CSV", command=self.import_csv).pack(side="right", padx=6)

        searchbar = ttk.Frame(self, padding=(18, 0, 18, 8))
        searchbar.pack(fill="x")
        ttk.Label(searchbar, text="Search:").pack(side="left")
        self.search_var = tk.StringVar()
        search = ttk.Entry(searchbar, textvariable=self.search_var, width=38)
        search.pack(side="left", padx=8)
        search.bind("<KeyRelease>", lambda _e: self.refresh())
        ttk.Button(searchbar, text="Clear", command=self.clear_search).pack(side="left")
        ttk.Label(searchbar, text="Search by bike, category, or notes", style="Sub.TLabel").pack(side="left", padx=12)

        table_frame = ttk.Frame(self, padding=(18, 0, 18, 12))
        table_frame.pack(fill="both", expand=True)
        cols = ("id", "bike", "date", "odo", "category", "next_km", "next_date", "status")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings", selectmode="browse")
        headings = {
            "id": "ID", "bike": "Bike", "date": "Service date", "odo": "Odometer",
            "category": "Category", "next_km": "Next service km", "next_date": "Next service date", "status": "Status"
        }
        widths = {"id": 45, "bike": 175, "date": 100, "odo": 95, "category": 135, "next_km": 115, "next_date": 125, "status": 110}
        for col in cols:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], anchor="w")
        yscroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)
        self.tree.tag_configure("overdue", foreground="#b91c1c")
        self.tree.tag_configure("soon", foreground="#b45309")
        self.tree.bind("<Double-1>", lambda _e: self.edit_record())

        footer = ttk.Frame(self, padding=(18, 6))
        footer.pack(fill="x")
        ttk.Label(footer, text="SQLite incremental persistence • CLI & GUI • automated logging • CSV / Markdown reports", style="Sub.TLabel").pack(side="left")
        ttk.Button(footer, text="Export Markdown report", command=self.export_markdown).pack(side="right")

    def refresh(self):
        try:
            all_records = manager.list_records()
            term = self.search_var.get().strip() if hasattr(self, "search_var") else ""
            visible = manager.search_records(query=term) if term else all_records
        except Exception:
            logging.exception("Could not query service records")
            messagebox.showerror("Storage error", "Could not read SQLite database.")
            return

        for row in self.tree.get_children():
            self.tree.delete(row)

        for r in visible:
            status = manager.status_for(r)
            tag = "overdue" if "OVERDUE" in status else ("soon" if "SOON" in status else "")
            self.tree.insert("", "end", iid=str(r["id"]), values=(
                r["id"], r["bike_name"], r["service_date"], f'{r["odometer_km"]:,} km',
                r["category"], f'{int(r.get("next_service_km") or 0):,}' if r.get("next_service_km") else "—",
                r.get("next_service_date") or "—", status
            ), tags=(tag,))

        due_count = sum("OVERDUE" in manager.status_for(r) or "SOON" in manager.status_for(r) for r in all_records)
        avg = sum(int(r.get("odometer_km", 0)) for r in all_records) / len(all_records) if all_records else 0
        self.metrics["records"].configure(text=str(len(all_records)))
        self.metrics["bikes"].configure(text=str(len({r.get("bike_name") for r in all_records})))
        self.metrics["due"].configure(text=str(due_count))
        self.metrics["average"].configure(text=f"{avg:,.0f} km")

    def selected(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showinfo("Select a record", "Please select a record first.")
            return None
        return manager.get_record(int(selection[0]))

    def add_record(self):
        dialog = ServiceDialog(self, "Add service record")
        self.wait_window(dialog)
        if dialog.result:
            new_id = manager.add_record(dialog.result)
            logging.info("GUI added service record #%s for %s", new_id, dialog.result["bike_name"])
            self.refresh()

    def edit_record(self):
        old = self.selected()
        if not old:
            return
        dialog = ServiceDialog(self, "Edit service record", old)
        self.wait_window(dialog)
        if dialog.result:
            manager.update_record(old["id"], dialog.result)
            logging.info("GUI updated service record #%s", old["id"])
            self.refresh()

    def delete_record(self):
        old = self.selected()
        if not old:
            return
        if messagebox.askyesno("Confirm delete", f'Delete service record #{old["id"]} for {old["bike_name"]}?'):
            manager.delete_record(old["id"])
            logging.info("GUI deleted service record #%s", old["id"])
            self.refresh()

    def clear_search(self):
        self.search_var.set("")
        self.refresh()

    def show_alerts(self):
        alerts = []
        for r in manager.list_records():
            status = manager.status_for(r)
            if status != "OK":
                alerts.append(
                    f'• {r["bike_name"]} — {status} | next service: '
                    f'{r.get("next_service_date") or "date not set"} | '
                    f'{r.get("next_service_km") or "km not set"} km'
                )
        messagebox.showinfo("Service alerts", "\n".join(alerts) if alerts else "No upcoming or overdue services.")

    def export_csv(self):
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")], initialfile="bike_service_report.csv")
        if not path:
            return
        records = manager.list_records()
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            writer.writeheader()
            for r in records:
                writer.writerow({k: r.get(k, "") for k in FIELDS})
        messagebox.showinfo("Export complete", f"Exported {len(records)} records.")

    def import_csv(self):
        path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not path:
            return
        imported = 0
        with open(path, "r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    cleaned = validate_record_data(row)
                    manager.add_record(cleaned)
                    imported += 1
                except ValueError:
                    continue
        logging.info("Imported %s records from %s", imported, path)
        self.refresh()
        messagebox.showinfo("Import complete", f"Imported {imported} valid records.")

    def export_markdown(self):
        path = filedialog.asksaveasfilename(defaultextension=".md", filetypes=[("Markdown files", "*.md")], initialfile="bike_service_report.md")
        if not path:
            return
        records = manager.list_records()
        lines = ["# Bike Service Log Report\n", "| ID | Bike | Date | Odometer | Category | Status |", "|---|---|---|---|---|---|"]
        for r in records:
            lines.append(f"| {r['id']} | {r['bike_name']} | {r['service_date']} | {r['odometer_km']} km | {r['category']} | {manager.status_for(r)} |")
        Path(path).write_text("\n".join(lines), encoding="utf-8")
        messagebox.showinfo("Export complete", "Markdown report generated.")


def launch_gui():
    app = BikeServiceApp()
    app.mainloop()


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Bike Service Log Pro 2.0 (CLI & Optional GUI)")
    parser.add_argument("--gui", action="store_true", help="Launch the Tkinter graphical user interface")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("list", help="List all service records")

    p_search = sub.add_parser("search", help="Search service records")
    p_search.add_argument("query", help="Keyword to search by bike, category, or notes")

    p_del = sub.add_parser("delete", help="Delete a record by ID")
    p_del.add_argument("id", type=int, help="Record ID")

    sub.add_parser("alerts", help="Show overdue and upcoming service alerts")
    sub.add_parser("stats", help="Show fleet maintenance statistics")

    p_exp = sub.add_parser("export", help="Export records to CSV")
    p_exp.add_argument("--out", default="bike_service_report.csv", help="Output CSV filename")

    return parser.parse_args(argv)


def main(argv=None):
    setup_logging()
    args = parse_args(argv)

    if args.gui:
        launch_gui()
    elif args.command == "list":
        print_records_table(manager.list_records())
    elif args.command == "search":
        print_records_table(manager.search_records(query=args.query))
    elif args.command == "delete":
        if manager.delete_record(args.id):
            print(f"Deleted record #{args.id}.")
        else:
            print(f"Record #{args.id} not found.")
    elif args.command == "alerts":
        cli_show_alerts()
    elif args.command == "stats":
        cli_show_stats()
    elif args.command == "export":
        cli_export_csv(args.out)
    else:
        run_interactive_cli()


if __name__ == "__main__":
    main()
