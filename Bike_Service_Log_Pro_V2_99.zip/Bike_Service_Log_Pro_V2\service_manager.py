﻿"""Business and persistence layer for Bike Service Log Pro."""
import json
import os
import sqlite3
from datetime import date, datetime
from pathlib import Path

FIELDS = (
    "id",
    "bike_name",
    "service_date",
    "odometer_km",
    "category",
    "notes",
    "next_service_km",
    "next_service_date",
    "current_odometer_km",
)

INSERT_FIELDS = FIELDS[1:]


class ServiceManager:
    def __init__(self, database_path=None):
        resolved_path = database_path or os.getenv("BIKE_SERVICE_DB_PATH", "data/bike_service.db")
        self.database_path = Path(resolved_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def connect(self):
        connection = sqlite3.connect(self.database_path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    def initialize(self):
        with self.connect() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS service_records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    bike_name TEXT NOT NULL,
                    service_date TEXT NOT NULL,
                    odometer_km INTEGER NOT NULL CHECK(odometer_km >= 0),
                    category TEXT NOT NULL,
                    notes TEXT NOT NULL,
                    next_service_km INTEGER NOT NULL DEFAULT 0 CHECK(next_service_km >= 0),
                    next_service_date TEXT NOT NULL DEFAULT '',
                    current_odometer_km INTEGER NOT NULL DEFAULT 0 CHECK(current_odometer_km >= 0)
                )
            """)
            con.execute("CREATE INDEX IF NOT EXISTS idx_service_bike ON service_records(bike_name)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_service_date ON service_records(service_date)")

            count = con.execute("SELECT COUNT(*) FROM service_records").fetchone()[0]
            legacy_path = os.getenv("BIKE_SERVICE_LEGACY_JSON")
            legacy = Path(legacy_path) if legacy_path else self.database_path.parent / "services.json"

            if count == 0 and legacy.exists():
                try:
                    items = json.loads(legacy.read_text(encoding="utf-8"))
                    for item in items if isinstance(items, list) else []:
                        values = [
                            item.get(k, 0 if k.endswith("_km") or k == "id" else "")
                            for k in FIELDS
                        ]
                        con.execute(
                            "INSERT OR IGNORE INTO service_records VALUES (?,?,?,?,?,?,?,?,?)",
                            values,
                        )
                except (OSError, ValueError, TypeError):
                    pass

    def list_records(self):
        with self.connect() as con:
            rows = con.execute(
                "SELECT * FROM service_records ORDER BY service_date DESC, id DESC"
            ).fetchall()
            return [dict(row) for row in rows]

    def get_record(self, record_id):
        with self.connect() as con:
            row = con.execute(
                "SELECT * FROM service_records WHERE id = ?", (record_id,)
            ).fetchone()
            return dict(row) if row else None

    def search_records(self, query="", status_filter="ALL"):
        sql = "SELECT * FROM service_records WHERE 1=1"
        params = []

        if query:
            sql += " AND (bike_name LIKE ? OR category LIKE ? OR notes LIKE ?)"
            like_term = f"%{query.strip()}%"
            params.extend([like_term, like_term, like_term])

        sql += " ORDER BY service_date DESC, id DESC"

        with self.connect() as con:
            records = [dict(row) for row in con.execute(sql, params).fetchall()]

        if status_filter and status_filter != "ALL":
            records = [
                r for r in records if self.status_for(r) == status_filter
            ]
        return records

    def add_record(self, record):
        values = [
            record.get(k, 0 if k.endswith("_km") else "")
            for k in INSERT_FIELDS
        ]
        with self.connect() as con:
            cursor = con.execute(
                """
                INSERT INTO service_records (
                    bike_name, service_date, odometer_km, category,
                    notes, next_service_km, next_service_date, current_odometer_km
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                values,
            )
            return cursor.lastrowid

    def update_record(self, record_id, record):
        values = [
            record.get(k, 0 if k.endswith("_km") else "")
            for k in INSERT_FIELDS
        ]
        values.append(record_id)
        with self.connect() as con:
            cursor = con.execute(
                """
                UPDATE service_records
                SET bike_name = ?,
                    service_date = ?,
                    odometer_km = ?,
                    category = ?,
                    notes = ?,
                    next_service_km = ?,
                    next_service_date = ?,
                    current_odometer_km = ?
                WHERE id = ?
                """,
                values,
            )
            return cursor.rowcount > 0

    def delete_record(self, record_id):
        with self.connect() as con:
            cursor = con.execute(
                "DELETE FROM service_records WHERE id = ?", (record_id,)
            )
            return cursor.rowcount > 0

    def get_summary_stats(self, today=None):
        records = self.list_records()
        status_counts = {"OVERDUE": 0, "DUE SOON": 0, "KM OVERDUE": 0, "KM SOON": 0, "OK": 0}
        bike_totals = {}

        for item in records:
            st = self.status_for(item, today=today)
            status_counts[st] = status_counts.get(st, 0) + 1
            bike = item.get("bike_name", "Unknown")
            bike_totals[bike] = bike_totals.get(bike, 0) + 1

        return {
            "total_records": len(records),
            "status_breakdown": status_counts,
            "records_per_bike": bike_totals,
        }

    @staticmethod
    def status_for(item, today=None):
        today = today or date.today()
        due_date = item.get("next_service_date", "")
        current = int(item.get("current_odometer_km") or 0)
        next_km = int(item.get("next_service_km") or 0)
        if due_date:
            try:
                parsed = datetime.strptime(due_date, "%Y-%m-%d").date()
                if parsed <= today:
                    return "OVERDUE"
                if (parsed - today).days <= 14:
                    return "DUE SOON"
            except ValueError:
                pass
        if current and next_km and current >= next_km:
            return "KM OVERDUE"
        if current and next_km and 0 <= next_km - current <= 500:
            return "KM SOON"
        return "OK"

