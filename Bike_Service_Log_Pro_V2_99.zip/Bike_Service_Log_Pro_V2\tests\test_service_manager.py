"""Automated pytest suite for ServiceManager."""
from datetime import date, timedelta
from service_manager import ServiceManager


def sample_record(**overrides):
    base = {
        "bike_name": "Yamaha MT-07",
        "service_date": "2025-05-01",
        "odometer_km": 12000,
        "category": "Oil & Filter",
        "notes": "Synthetic 10W-40",
        "next_service_km": 17000,
        "next_service_date": "",
        "current_odometer_km": 12500,
    }
    base.update(overrides)
    return base


def test_incremental_crud_lifecycle(tmp_path):
    db_file = tmp_path / "test_services.db"
    mgr = ServiceManager(db_file)

    rec_id = mgr.add_record(sample_record())
    assert rec_id == 1

    fetched = mgr.get_record(rec_id)
    assert fetched is not None
    assert fetched["bike_name"] == "Yamaha MT-07"
    assert fetched["odometer_km"] == 12000

    updated_data = sample_record(odometer_km=12200, notes="Updated notes")
    assert mgr.update_record(rec_id, updated_data) is True
    assert mgr.get_record(rec_id)["notes"] == "Updated notes"

    assert mgr.delete_record(rec_id) is True
    assert mgr.get_record(rec_id) is None


def test_search_and_summary_stats(tmp_path):
    db_file = tmp_path / "test_search.db"
    mgr = ServiceManager(db_file)

    mgr.add_record(sample_record(bike_name="Honda CB500X", category="Chain Lube"))
    mgr.add_record(sample_record(bike_name="Yamaha MT-07", category="Brake Pads"))

    results = mgr.search_records(query="Honda")
    assert len(results) == 1
    assert results[0]["bike_name"] == "Honda CB500X"

    stats = mgr.get_summary_stats()
    assert stats["total_records"] == 2
    assert stats["records_per_bike"]["Honda CB500X"] == 1
    assert stats["records_per_bike"]["Yamaha MT-07"] == 1


def test_status_calculation():
    today = date(2025, 5, 20)
    overdue_item = sample_record(next_service_date=(today - timedelta(days=1)).isoformat())
    soon_item = sample_record(next_service_date=(today + timedelta(days=5)).isoformat())
    km_overdue = sample_record(next_service_km=15000, current_odometer_km=15200)
    ok_item = sample_record(next_service_km=18000, current_odometer_km=12000)

    assert ServiceManager.status_for(overdue_item, today=today) == "OVERDUE"
    assert ServiceManager.status_for(soon_item, today=today) == "DUE SOON"
    assert ServiceManager.status_for(km_overdue, today=today) == "KM OVERDUE"
    assert ServiceManager.status_for(ok_item, today=today) == "OK"
